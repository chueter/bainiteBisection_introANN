import tensorflow as tf
#from tensorflow import keras
#from tensorflow.keras import layers
#from tensorflow.contrib.data import CsvDataset
import numpy as np
import sklearn
from sklearn.model_selection import train_test_split

# validationLoop
validation_runs = 3

# optimisation variables
learning_rate = 0.1
epochs = 5000

#NN structure parameters
NInput = 2
Nodes1stLayer = 3
Nodes2ndLayer = 0
NOutput = 1
NBiasNodes = 0
testFrac = 0.25
NData = 93

NDOF = NData-9
print("NDOF = ", NDOF)

# declare the training data placeholders
# input x: different compositions
X = tf.placeholder(tf.float32, [None, NInput], name="composition")

# declare the output data placeholder - lower bainite transition temperature
Y = tf.placeholder(tf.float32, [None, 1], name='lowerbainitetrans')

# now declare the weights connecting the input to the 1st hidden layer
W1 = tf.get_variable("W1", shape=[NInput, Nodes1stLayer], initializer=tf.contrib.layers.xavier_initializer())
b1 = tf.get_variable("b1", shape=[Nodes1stLayer], initializer=tf.contrib.layers.xavier_initializer())

# adding activation function in the 1st hidden layer
#h1_out= tf.nn.tanh((tf.matmul(X, W1)+b1), name='activationLayer1')
h1_out= tf.nn.tanh((tf.matmul(X, W1)), name='activationLayer1')
'''
#now declare the weights connecting the 1st hidden layer to the 2nd hidden layer
W2 = tf.get_variable("W2", shape=[Nodes1stLayer, Nodes2ndLayer], initializer=tf.contrib.layers.xavier_initializer())
b2 = tf.get_variable("b2", shape=[Nodes2ndLayer], initializer=tf.contrib.layers.xavier_initializer())

# adding activation function in the 2nd hidden layer
#h2_out= tf.nn.tanh((tf.matmul(h1_out, W2)+b2), name='activationLayer2')
h2_out= tf.nn.tanh((tf.matmul(h1_out, W2)), name='activationLayer2')
'''
# the weights connecting the 2nd hidden layer to the output layer
W3 = tf.get_variable("W3", shape=[Nodes1stLayer, NOutput], initializer=tf.contrib.layers.xavier_initializer())
b3 = tf.get_variable("b3", shape=[NOutput], initializer=tf.contrib.layers.xavier_initializer())

#linear activation function at output layer
y_pre = tf.add(tf.matmul(h1_out, W3), 0., name='prediction')

#cost function, mean square error between predicted y_pred and target Y
cost = tf.losses.mean_squared_error(labels=Y, predictions=y_pre)

#optimizer
optimizer = tf.train.GradientDescentOptimizer(learning_rate).minimize(cost)

# define an accuracy assessment operation
AbsoluteDifference = tf.reduce_mean(tf.reduce_sum(tf.abs(tf.subtract(y_pre, Y))/Y, 0), 0)
unbiasedMSE = tf.reduce_mean(tf.reduce_sum(tf.abs(tf.subtract(y_pre, Y))/Y, 0), 0)/(NDOF)

# initialization of all variables
initial = tf.global_variables_initializer()

# option to save and restore all the variables
saver = tf.train.Saver()

#loading training data
t=np.loadtxt("93Aug_Idx_C_Mn_Texp.csv")

x_np=t[:,:-1] #[row, column]

x_list=x_np.tolist()

#print(x_list[0:2])
#exit(1)
y_np=t[:,-1]

y_list=[]

y_size=y_np.size

for i in range(y_size):
    y_list.append([y_np[i]])

#print(y_list)

#normalization of temperature to [0.1, 0.9]
y_min=np.min(y_list)
y_max=np.max(y_list)
delt_y = np.subtract(y_max,y_min)
y_normal= np.add(np.multiply(np.divide(np.subtract(y_list, y_min), delt_y), 0.8), 0.1)
#print y_normal


predVals = tf.add(tf.multiply(tf.multiply(tf.subtract(y_pre,0.1),1.25),delt_y),y_min)

############# here validation loop begins ####################
f = open("validationOutput.csv", "a")

for run in range(0,validation_runs):
    
    #splite data into training data and testing data
    X_train, X_test, Y_train, Y_test = train_test_split(x_list, y_normal, test_size=testFrac)
    Num_X_train = len(X_train)
    #print ("number of training samples:", Num_X_train)

    ########### here begins convergence loop #################
    #the model saving is done non-persistentely, thus only the currently converging model data is saved
    with tf.Session() as sess:
        sess.run(initial)
    # initialise the variables
        for epoch in range(epochs+1):
            op, c = sess.run([optimizer, cost], feed_dict={X: X_train, Y: Y_train})
            if (epoch % (epochs/10) == 0):
                print("Epoch:", (epoch + 1), "cost =", "{:.10f}".format(c))
            
                print("run =", run)
                print("Absolute Difference of testing sample", sess.run(AbsoluteDifference, feed_dict={X: X_test, Y: Y_test}))
                print("Unbiased ME=ME*N/(N-P)", sess.run(unbiasedMSE, feed_dict={X: X_test, Y: Y_test}))

        predFullData = sess.run(predVals, feed_dict={X: x_list, Y: y_normal})
            #print(str(predFullData[0][0]))
            #exit(1)
        save_path = saver.save(sess, './trained_model'+'_'+str(run))

        f.write(str(run)+" "+str(sess.run(AbsoluteDifference, feed_dict={X: X_test, Y: Y_test}))+" "+str(sess.run(unbiasedMSE, feed_dict={X: X_test, Y: Y_test}))+"\n")



    with open('data'+str(run)+'Out.csv','w') as outFile:
        for idx in range(NData):
            outString = str([x_list[idx][0],x_list[idx][1],y_list[idx][0],predFullData[idx][0],(y_list[idx][0]-predFullData[idx][0])/(0.5*(y_list[idx][0]+predFullData[idx][0]))]).strip("[").strip("]").strip(",")+"\n"
            outFile.write(outString)
            #outFile.write("model:Wfeal,Wfemn,loss,sfe0,Wc,Wal,Wmnc, loss:"+str(curr_loss))
    

f.close()
