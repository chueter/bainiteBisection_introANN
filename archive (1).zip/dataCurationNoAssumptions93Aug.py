import numpy as np
#import tensorflow as tf
import csv
#from sklearn.model_selection import train_test_split

inFile = open("summarizingTable93.csv","r")
dataExp = []

for inLine in inFile.read().split('\n'):
    line = []
    dataExp.append(inLine.split(','))

inFile.close()

inFile = open("MuFCC93.csv","r")
dataDB = []

for inLine in inFile.read().split('\n'):
    line = []
    dataDB.append(inLine.split(';'))

inFile.close()
#print(dataExp[0],"\n")
#print(dataExp[-1],"\n")
#print(dataDB[0],"\n")
#print(dataDB[-1],"\n")
dataColl = list(zip(dataExp,dataDB))
dataExc = []
for el in dataColl:
    #el[0][0],
    el = [el[0][1],el[0][2],str(el[1][1]).replace(",","."),el[0][10]]
    dataExc.append(el)
#print(dataExc[0])
#print(dataExc[-1])
#excerpt file is -- index c mn T_exp mu_c --
#print(data[2:-4])
#exit(1)
#for el in dataExc:
#    print(el,"\n")
#exit(1)
# dataExc looks good! no errro data points a priori, just need scaling
#curedDataSet = []

#codeValAsterisk = ord(data[70][0][2]) #that is the * character which is not natively recognised by python
'''
for dataPoint in dataExc:
    idx = dataPoint[0]
    curedDataPoint = []
    reducedDataPoint = []
    elCnt = 1
    for el in dataPoint:
        el = el.replace(',', '.')
        if (elCnt < 17):
            if((el=='')):
                curedDataPoint.append(float("-1."))
                elCnt +=1
            else:
                try:
                    curedDataPoint.append(float(el))
                    elCnt += 1
                except:
                    curedDataPoint.append(float("-1."))
                    elCnt +=1
    curedDataPoint[0] = float(idx)
    reducedDataPoint = str([curedDataPoint[1],curedDataPoint[2],curedDataPoint[3],(curedDataPoint[6]+8600.)/40000.,curedDataPoint[4]])
    reducedDataPoint = reducedDataPoint.replace(","," ")
    curedDataSet.append(reducedDataPoint.strip('[').strip(']'))
'''

outFile = open("93Aug_Idx_C_Mn_Texp_MuC.csv","w")
outFile.close()

for line in dataExc:
    outFile = open("93Aug_Idx_C_Mn_Texp_MuC.csv","a")
    outFile.write(str(line).strip('[').strip(']').replace("'","").replace(',',' '))
    outFile.write("\n")
    outFile.close()

exit(1)
