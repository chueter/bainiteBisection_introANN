import tensorflow as tf
#from tensorflow import keras
#from tensorflow.keras import layers
#from tensorflow.contrib.data import CsvDataset
import numpy as np
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.model_selection import LeaveOneOut #only when optimal topology is determined (if at all)
import matplotlib.pyplot as plt
from sklearn.preprocessing import QuantileTransformer

inFile = open("summarizingTableOnlyCol1and2Complete.csv")
'''
    the file 93Aug_C_Mn_FeApprox_Texp.csv has a changed sequence of the data points; the
    file summarizingTableOnlyCol1and2Complete.csv does not - therefore we have to
    adapt the sequence in the array extracted from summarizingTableOnlyCol1and2Complete.csv to match
    that of 93Aug_C_Mn_FeApprox_Texp.csv
'''

data = []
import numpy as np

for inLine in inFile.read().split('\n'):
    line = []
    data.append(inLine.split(','))

inFile.close()


'''
MaxC = float(max(dp[1] for dp in data))
MaxMn = float(max(dp[2] for dp in data))
MaxV = float(max(dp[3] for dp in data))
MaxSi = float(max(dp[4] for dp in data))
MaxCr = float(max(dp[5] for dp in data))
MaxMo = float(max(dp[6] for dp in data))
MaxNi = float(max(dp[7] for dp in data))
MaxW = float(max(dp[8] for dp in data))

imputedData = []
for idx in range(len(data)):
    locC = 0.6*MaxC if (np.fabs(float(data[idx][1]))<1e-8) else data[idx][1]
    #print(idx,locC)
    locMn = 0.6*MaxMn if (np.fabs(float(data[idx][2]))<1e-8) else data[idx][2]
    #print(idx,locMn)
    #print(idx,np.fabs(float(data[idx][3])),MaxV)
    locV = 0.6*MaxV if (np.fabs(float(data[idx][3]))<1e-8) else data[idx][3]
    locSi = 0.6*MaxSi if (np.fabs(float(data[idx][4]))<1e-8) else data[idx][4]
    locCr = 0.6*MaxCr if (np.fabs(float(data[idx][5]))<1e-8) else data[idx][5]
    locMo = 0.6*MaxMo if (np.fabs(float(data[idx][6]))<1e-8) else data[idx][6]
    locNi = 0.6*MaxNi if (np.fabs(float(data[idx][7]))<1e-8) else data[idx][7]
    locW = 0.6*MaxW if (np.fabs(float(data[idx][8]))<1e-8) else data[idx][8]
    locT = data[idx][10]
    imputedData.append([locC,locMn,locV,locSi,locCr,locMo,locNi,locW,locT])
'''

# validationLoop
validation_runs = 10 #equal to CV splitting parameter!

NData = len(data)

#loading training data
t1=np.loadtxt("93Aug_C_Mn_FeApprox_Texp.csv")
t2=np.loadtxt("idxMinMaxTChemPotC.csv")

x_np1=t1[:,:-1] #[row, column] requires that predicted value is always in last column!; also mu c is in 2nd last column
x_np2=t2
'''
muTminList = []
for el in x_np2:
    val = float(el[1])
    muTminList.append(val)
'''
muTmaxList = []
for el in x_np2:
    val = float(el[2])
    muTmaxList.append(val)

x_np2_norm = []
for el in x_np2:
    x_np2_norm.append([0.1+(float(el[2])-np.min(muTmaxList))/(1.25*(np.max(muTmaxList)-np.min(muTmaxList)))])

CList = []
for el in x_np1:
    val = float(el[0])
    CList.append(val)

MnList = []
for el in x_np1:
    val = float(el[1])
    MnList.append(val)

FeList = []
for el in x_np1:
    val = float(el[2])
    FeList.append(val)

x_np1_norm = []
for el in x_np1:
    x_np1_norm.append([0.1+(float(el[0])-np.min(CList))/(1.25*(np.max(CList)-np.min(CList))),0.1+(float(el[1])-np.min(MnList))/(1.25*(np.max(MnList)-np.min(MnList))),0.1+(float(el[2])-np.min(FeList))/(1.25*(np.max(FeList)-np.min(FeList)))])

x_list=[ [x_np1_norm[i][0],x_np1_norm[i][1],x_np1_norm[i][2], x_np2_norm[i][0]] for i in xrange(0,len(x_np1_norm)) ]

kf = KFold(n_splits=validation_runs)
kf.get_n_splits(np.array(x_list))
#print(kf)
KFold(n_splits=10, random_state=None, shuffle=False)
#for train_index, test_index in kf.split(np.array(x_list)):
    #print("TRAIN:", train_index, "TEST:", test_index)

splitsTrainList = []
splitsTestList = []
for el in kf.split(np.array(x_list)):
    splitsTrainList.append(el[0])
    splitsTestList.append(el[1])

#print(splitsTrainList[0]) #splitsTrainList[i] contains the 93-10/9 training data points for the ith group
y_np=t1[:,-1]

y_list=[]

y_size=y_np.size

for i in range(y_size):
    y_list.append([y_np[i]])

#print(y_list)

#normalization of temperature to [0.1, 0.9]
y_min=np.min(y_list)
y_max=np.max(y_list)

y_normList = []
for idx in range(len(y_list)):
    y_normList.append(0.1+0.8*(y_list[idx]-y_max)/(y_max-y_min))


#define 10 tmax values for the genration of the chemical potentials, each tmax being the tmax of the
#ith group used for the 10 fold CV
subgroupsT = []
for idx in range(validation_runs):
    #print("idx: ", idx)
    #print(splitsTestList[idx])
    subgroupT = []
    for idx2 in splitsTrainList[idx]:
        #print(idx2)
        subgroupT.append([y_normList[idx2][0],y_list[idx2][0],idx2])
    subgroupsT.append(subgroupT)


tminmaxOfSubgroupsT = []

for subgroupT in subgroupsT:
    tmax = 0.
    tmin = 1e5
    for datapointT in subgroupT:
        #print(float(datapoint[1]))
        if float(datapointT[1]) > tmax:
            tmax = float(datapointT[1])
        if float(datapointT[1]) < tmin:
            tmin = float(datapointT[1])
    tminmaxOfSubgroupsT.append([tmin,tmax])

print(tminmaxOfSubgroupsT)

'''
here we adapt the sequence of data to that of x_list
'''
modSeqData = []

for el1 in x_np1:
    for el2 in data:
        if ((float(el2[1])==el1[0]) and (float(el2[2])==el1[1])):
            modSeqData.append(el2)
'''
for idx in range(len(modSeqData)):
    print(idx)
    print(modSeqData[idx][:3])
    print(x_np1[idx])
    print()
exit(1)
''' # adapted sequence correct



for idx in range(validation_runs):
    tIni = tminmaxOfSubgroupsT[idx][0]+0.5*(tminmaxOfSubgroupsT[idx][1]-tminmaxOfSubgroupsT[idx][0])
    print(tIni)
    subGroup = [ modSeqData[sgIdx] for sgIdx in splitsTrainList[idx]]
        #for el in subGroup:
        #    print(el)
        #exit(1)
    with open("XiaoyanMacroMuFccAtTIni_sg"+str(idx)+".txt", "w") as textFile:
        textFile.write("set-echo \n")
        textFile.write("go dat \n")
        textFile.write("def-ele: Fe, C, Mn, V, Si, Cr, Mo, Ni, W \n")
        textFile.write("rej p * \n")
        textFile.write("rest p fcc \n")
        textFile.write("get \n")
        textFile.write("go poly \n")
        for dataPoint in subGroup:
            textFile.write("s-c: w(C)="+str(0.01*float(dataPoint[1]))+", w(Mn)="+str(0.01*float(dataPoint[2]))+", w(V)="+str(0.01*float(dataPoint[3]))+", w(Si)="+str(0.01*float(dataPoint[4]))+", w(Cr)="+str(0.01*float(dataPoint[5]))+", w(Mo)="+str(0.01*float(dataPoint[6]))+", w(Ni)="+str(0.01*float(dataPoint[7]))+", w(W)="+str(0.01*float(dataPoint[8]))+", N=1, p=1e5, T="+str(273.15+tIni)+"\n"+"l-c"+"\n"+"c-e"+"\n"+"l-e"+"\n"+str(dataPoint[0])+".txt"+"\n\n")







exit(1)

