import tensorflow as tf
#from tensorflow import keras
#from tensorflow.keras import layers
#from tensorflow.contrib.data import CsvDataset
import numpy as np
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.model_selection import LeaveOneOut #only when optimal topology is determined (if at all)



# validationLoop
validation_runs = 10 #equal to CV splitting parameter!

# optimisation variables
learning_rate = 0.1
epochs = 1000000

#NN structure parameters
NInput = 3
Nodes1stLayer = 5
Nodes2ndLayer = 5
NOutput = 1
NBiasNodes = 0
#testFrac = 0.25
NData = 93

NDOF = NData-45
print("NDOF = ", NDOF)

# declare the training data placeholders
# input x: different compositions
X = tf.placeholder(tf.float32, [None, NInput], name="composition")

# declare the output data placeholder - lower bainite transition temperature
Y = tf.placeholder(tf.float32, [None, 1], name='lowerbainitetrans')

# now declare the weights connecting the input to the 1st hidden layer
W1 = tf.get_variable("W1", shape=[NInput, Nodes1stLayer], initializer=tf.contrib.layers.xavier_initializer())
b1 = tf.get_variable("b1", shape=[Nodes1stLayer], initializer=tf.contrib.layers.xavier_initializer())

# adding activation function in the 1st hidden layer
#h1_out= tf.nn.tanh((tf.matmul(X, W1)+b1), name='activationLayer1')
h1_out= tf.nn.tanh((tf.matmul(X, W1)), name='activationLayer1')

#now declare the weights connecting the 1st hidden layer to the 2nd hidden layer
W2 = tf.get_variable("W2", shape=[Nodes1stLayer, Nodes2ndLayer], initializer=tf.contrib.layers.xavier_initializer())
b2 = tf.get_variable("b2", shape=[Nodes2ndLayer], initializer=tf.contrib.layers.xavier_initializer())

# adding activation function in the 2nd hidden layer
#h2_out= tf.nn.tanh((tf.matmul(h1_out, W2)+b2), name='activationLayer2')
h2_out= tf.nn.tanh((tf.matmul(h1_out, W2)), name='activationLayer2')

# the weights connecting the 2nd hidden layer to the output layer
W3 = tf.get_variable("W3", shape=[Nodes2ndLayer, NOutput], initializer=tf.contrib.layers.xavier_initializer())
b3 = tf.get_variable("b3", shape=[NOutput], initializer=tf.contrib.layers.xavier_initializer())

#linear activation function at output layer
y_pre = tf.add(tf.matmul(h2_out, W3), 0., name='prediction')

#cost function, mean square error between predicted y_pred and target Y
cost = tf.losses.mean_squared_error(labels=Y, predictions=y_pre)

#optimizer
optimizer = tf.train.GradientDescentOptimizer(learning_rate).minimize(cost)

# define an accuracy assessment operation
AbsoluteDifference = tf.reduce_mean(tf.reduce_sum(tf.abs(tf.subtract(y_pre, Y))/Y, 0), 0)
unbiasedMSE = tf.reduce_mean(tf.reduce_sum(tf.abs(tf.subtract(y_pre, Y))/Y, 0), 0)/(NDOF)

# initialization of all variables
initial = tf.global_variables_initializer()

# option to save and restore all the variables
saver = tf.train.Saver()

#loading training data
t1=np.loadtxt("93Aug_C_Mn_FeApprox_Texp.csv")
#t2=np.loadtxt("idxMinMaxTChemPotC.csv")

x_np1=t1[:,:-1] #[row, column] requires that predicted value is always in last column!; also mu c is in 2nd last column
#x_np2=t2
'''
muTminList = []
for el in x_np2:
    val = float(el[1])
    muTminList.append(val)

muTmaxList = []
for el in x_np2:
    val = float(el[2])
    muTmaxList.append(val)

x_np2_norm = []
for el in x_np2:
    x_np2_norm.append([float(el[0]),0.1+(float(el[1])-np.min(muTminList))/(1.25*(np.max(muTminList)-np.min(muTminList))),0.1+(float(el[2])-np.min(muTmaxList))/(1.25*(np.max(muTmaxList)-np.min(muTmaxList)))])
'''
CList = []
for el in x_np1:
    val = float(el[0])
    CList.append(val)

MnList = []
for el in x_np1:
    val = float(el[1])
    MnList.append(val)

FeList = []
for el in x_np1:
    val = float(el[2])
    FeList.append(val)

x_np1_norm = []
for el in x_np1:
    x_np1_norm.append([0.1+(float(el[0])-np.min(CList))/(1.25*(np.max(CList)-np.min(CList))),0.1+(float(el[1])-np.min(MnList))/(1.25*(np.max(MnList)-np.min(MnList))),0.1+(float(el[2])-np.min(FeList))/(1.25*(np.max(FeList)-np.min(FeList)))])

#x_list=list(zip(x_np1.tolist(),x_np2.tolist())) #gives a double nested list, not a simply nested list
#x_list=[ [x_np1.tolist()[i][0],x_np1.tolist()[i][1],x_np2_norm.tolist()[i][1],x_np2_norm.tolist()[i][2]] for i in xrange(0,len(x_np1.tolist())) ]
x_list=[ [x_np1_norm[i][0],x_np1_norm[i][1],x_np1_norm[i][2]] for i in xrange(0,len(x_np1_norm)) ]

kf = KFold(n_splits=validation_runs)
kf.get_n_splits(np.array(x_list))
#print(kf)
KFold(n_splits=10, random_state=None, shuffle=False)
#for train_index, test_index in kf.split(np.array(x_list)):
    #print("TRAIN:", train_index, "TEST:", test_index)

splitsTrainList = []
splitsTestList = []
for el in kf.split(np.array(x_list)):
    splitsTrainList.append(el[0])
    splitsTestList.append(el[1])

#print(splitsTrainList[3])
#print(splitsTestList[3])
#exit(1)
#print(x_list[0])
#print(x_list[-1])
#exit(1)
y_np=t1[:,-1]

y_list=[]

y_size=y_np.size

for i in range(y_size):
    y_list.append([y_np[i]])

#print(y_list)

#normalization of temperature to [0.1, 0.9]
y_min=np.min(y_list)
y_max=np.max(y_list)
delt_y = np.subtract(y_max,y_min)
y_normal= np.add(np.multiply(np.divide(np.subtract(y_list, y_min), delt_y), 0.8), 0.1)
#print y_normal


predVals = tf.add(tf.multiply(tf.multiply(tf.subtract(y_pre,0.1),1.25),delt_y),y_min)

############# here validation loop begins ####################
f = open("validationOutput.csv", "a")

for run in range(0,validation_runs):
    fDetString = "detailedEvolution_"+str(run)+".csv"
    fDet = open(fDetString, "a")
    #splite data into training data and testing data
    #X_train, X_test, Y_train, Y_test = np.array([ x_list[idx] for idx in splitsTrainList[run]]), np.array([ x_list[idx] for idx in splitsTestList[run]]), np.array([ y_normal[idx] for idx in splitsTrainList[run]]), np.array([ y_normal[idx] for idx in splitsTestList[run]])
    X_train, X_test, Y_train, Y_test = [ x_list[idx] for idx in splitsTrainList[run]], [ x_list[idx] for idx in splitsTestList[run]], [ y_normal[idx] for idx in splitsTrainList[run]], [ y_normal[idx] for idx in splitsTestList[run]]
    Num_X_train = len(X_train)
    
    
    #print(run, X_train)
    #print(run, X_test)
    # exit(1)
    #print(run, Y_train)
    #print(run, Y_test)
    #print ("number of training samples:", Num_X_train) #yepp this works as it should !
    
    
    ########### here begins convergence loop #################
    #the model saving is done non-persistentely, thus only the currently converging model data is saved
    with tf.Session() as sess:
        sess.run(initial)
    # initialise the variables
        for epoch in range(epochs+1):
            op, c = sess.run([optimizer, cost], feed_dict={X: X_train, Y: Y_train})
            if (epoch % (epochs/10) == 0):
                print("Epoch:", (epoch + 1), "cost =", "{:.10f}".format(c))
            
                print("run =", run)
                print("Absolute Difference of testing sample", sess.run(AbsoluteDifference, feed_dict={X: X_test, Y: Y_test}))
                print("Unbiased ME=ME*N/(N-P)", sess.run(unbiasedMSE, feed_dict={X: X_test, Y: Y_test}))
                fDet.write(str(run)+" "+str(epoch)+" "+"{:.10f}".format(c)+" "+str(sess.run(AbsoluteDifference, feed_dict={X: X_test, Y: Y_test}))+" "+str(sess.run(unbiasedMSE, feed_dict={X: X_test, Y: Y_test}))+"\n")
    
        predFullData = sess.run(predVals, feed_dict={X: x_list, Y: y_normal})
            #print(str(predFullData[0][0]))
            #exit(1)
        save_path = saver.save(sess, './trained_model'+'_'+str(run))

        f.write(str(run)+" "+str(sess.run(AbsoluteDifference, feed_dict={X: X_test, Y: Y_test}))+" "+str(sess.run(unbiasedMSE, feed_dict={X: X_test, Y: Y_test}))+"\n")

    fDet.close()

    with open('data'+str(run)+'Out.csv','w') as outFile:
        for idx in range(NData):
            outString = str([x_list[idx][0],x_list[idx][1],x_list[idx][2],y_list[idx][0],predFullData[idx][0],(y_list[idx][0]-predFullData[idx][0])/(0.5*(y_list[idx][0]+predFullData[idx][0]))]).strip("[").strip("]").strip(",")+"\n"
            outFile.write(outString)
            #outFile.write("model:Wfeal,Wfemn,loss,sfe0,Wc,Wal,Wmnc, loss:"+str(curr_loss))
    

f.close()
